#include <bits/stdc++.h>
#include "socketstream.hh"

using namespace swoope;
using namespace std;

struct hand {						
	int *fingers;
	int *max_fingers;
	bool is_dead;

	hand(int max_f) {
		fingers = new int;
		*fingers = 1;
		max_fingers = new int;
		*max_fingers = max_f;
		is_dead = false;
	};

	void addFingers(int a) {
		int total_fingers = a + *fingers;
		if (total_fingers == *max_fingers) {
			is_dead = true;
		} else if (total_fingers > *max_fingers){
			total_fingers -= *max_fingers;
		}
		*fingers = total_fingers;
	};
};

struct foot {
	int *toes;
	int *max_toes;
	bool is_dead;

	foot(int max_t) {
		toes = new int;
		*toes = 1;
		max_toes = new int;
		*max_toes = max_t;
		is_dead = false;
	};

	void addToes(int a) {
		int total_toes = a + *toes;
		if (total_toes >= *max_toes) {
			is_dead = true;
		}
		*toes = total_toes;
	};
};

class Player {
protected:
	int p_number;
	string p_type;
	bool player_is_dead;
	bool my_turn;
	bool i_skip_turn;
	bool starting_h_dead;

public:
	vector <hand*> hands;
	vector <foot*> feet;

	// virtual string getPlayerType() const = 0;

	void tap(Player *target, int att_no, int rec_no, string att_part, string rec_part) {
		//cout << rec_part << att_part << endl;
		if (this->getPlayerType() != "doggo" && target->getPlayerType() == "doggo") {
			this->setSkipTurn(true);
		}
		if (att_part == "hand") {
			if (rec_part == "hand") {
				//cout << "target hands "<< target->hands[rec_no]->fingers <<endl;

				target->hands[rec_no]->addFingers(*this->hands[att_no]->fingers);
				//cout << "target hands "<< target->hands[rec_no]->fingers <<endl;

				if (target->hands[rec_no]->is_dead && target->getPlayerType() == "zombie" && target->getBoolStartingHand()){
					hand *h = new hand(4);
					target->hands.push_back(h);
					target->setBoolStartingHand(false);
				}
			}
			else {
				target->feet[rec_no]->addToes(*this->hands[att_no]->fingers);
			}
		}
		else { //att_part == foot
			if (rec_part == "hand") {
				target->hands[rec_no]->addFingers(*this->feet[att_no]->toes);

				//zombie case
				if (target->hands[rec_no]->is_dead && target->getPlayerType() == "zombie" && target->getBoolStartingHand()){
					hand *h = new hand(4);
					target->hands.push_back(h);
					target->setBoolStartingHand(false);
				}
			}
			else {

				target->feet[rec_no]->addToes(*this->feet[att_no]->toes);
				if (target->getPlayerType() != "alien" && target->feet[rec_no]->is_dead) {
					target->setSkipTurn(true);
				}
			}
		}
	};

	bool isTapValid(int num, int num_players, Player *target, int att_no, int rec_no, string att_part, string rec_part, vector<vector<Player*>> &v_of_teams, int team){
    	//exceed num_players
		if (num > num_players) return false;
		//friendly fire
    	for (int i = 0; i < v_of_teams[team].size(); i++){
			if (v_of_teams[team][i]->getPlayerNum() == target->getPlayerNum()) return false;
		}
    	if(this->getPlayerNum() == target->getPlayerNum()) return false;

    	//att_part
    	if (att_part == "hand"){
    	    //att_part is dead
    	    if (this->hands[att_no]->is_dead) return false;

    	    //rec_part case
    	    if (rec_part == "hand"){
    	        if(target->hands[rec_no]->is_dead) return false;
    	    }
    	    else if (rec_part == "feet"){
    	        if(target->feet[rec_no]->is_dead) return false;
    	    }
    	}
    	else if (att_part == "foot") {
    	    //att_part is dead
    	    if (this->feet[att_no]->is_dead) return false;

    	    //rec_part case
    	    if (rec_part == "hand"){
    	        if(target->hands[rec_no]->is_dead) return false;
    	    }
    	    else if (rec_part == "feet"){
    	        if(target->feet[rec_no]->is_dead) return false;
    	    }
    	}

    	return true;
    };

	void dist(vector<int> &distNums, string part){

		if(part == "hand"){
			for(int i = 0; i < distNums.size(); i++){
				*this->hands[i]->fingers = distNums[i];
			}
		} else { //part =="feet"
			for(int i = 0; i < distNums.size(); i++){
				*this->feet[i]->toes = distNums[i];
			}
		}
	};

	bool isDistValid(vector<int> &distNums) {

		//count alive hands
		int handCount = 0;
		for (int i = 0; i < this->hands.size(); i++) {
			if (!this->hands[i]->is_dead) {
				handCount += 1;
			}
		}
		if (handCount < 2) {
			return false;
		}
		if (handCount != distNums.size()) {
			return false;
		}

		int currFingers = 0;
		for (int i = 0; i < this->hands.size(); i++) {
			currFingers += *this->hands[i]->fingers;
		}
	
		int distFingers = 0;
		for (int i = 0; i < distNums.size(); i++) {
			distFingers += distNums[i];
		}

		if (currFingers != distFingers) return false;
		

		//dist has no change
		bool distChange = false;
		for(int i = 0; i < this->hands.size(); i++){
			int index = 0;
			if(this->hands[i]->fingers == this->hands[i]->max_fingers){
				index += 1; i--;    
				continue;
			}
			if (distNums[i] != *this->hands[i+index]->fingers){
				distChange = true;
			}
		}
		if (!distChange) return false;

		return true;
	}
	
	bool getMyTurn() {
		return my_turn;
	};

	void setMyTurn(bool a) {
		my_turn = a;
	};

	bool getSkipTurn() {
		return i_skip_turn;
	};

	void setSkipTurn(bool a) {
		i_skip_turn = a;
	};

	bool getBoolStartingHand() {
		return starting_h_dead;
	};

	void setBoolStartingHand(bool a) {
		starting_h_dead = a;
	};

	bool getPlayerlife() {
		return player_is_dead;
	};

	string getPlayerType() {
		return p_type;
	};

	int getPlayerNum() {
		return p_number;
	};

	string printPlayerState(){
		// cout << "checkfunc1" << endl;		

		string state = "P";
		state += to_string(this->getPlayerNum()) + this->getPlayerType()[0];

		state += "("; /*cout << this->hands[0]->fingers << endl;*/
		for(int i = 0; i < this->hands.size(); i++){
			if (*this->hands[i]->fingers >= *this->hands[i]->max_fingers){
				state += "X";
			}
			else state += to_string(*this->hands[i]->fingers);
		}


		state += ":";

		for(int i = 0; i < this->feet.size(); i++){
			if (*this->feet[i]->toes >= *this->feet[i]->max_toes){
				state += "X";
			}
			else state += to_string(*this->feet[i]->toes);
		}

		state += ")";


		return state;
	};

	bool playerAlive(){
		for (int i = 0; i < this->hands.size();i++){
			if (*this->hands[i]->fingers < *this->hands[i]->max_fingers){
				return true;
			}
		}
		for (int i = 0; i < this->feet.size();i++){
			if (*this->feet[i]->toes < *this->feet[i]->max_toes){
				return true;
			}
		}
		return false;
	};
};

class Human : public Player {
public:
	Human(int p_number) {
		for (int i = 0; i < 2; i++) {
			hand *h = new hand(5);
			hands.push_back(h);
		}
		for (int i = 0; i < 2; i++) {
			foot *f = new foot(5);
			feet.push_back(f);
		}
		this->p_number = p_number;
		p_type = "human";
		this->player_is_dead = false;
		starting_h_dead = false;
		my_turn = false;
		i_skip_turn = false;
	};
};

class Alien : public Player{
public:
	Alien(int p_number) {
		for (int i = 0; i < 4; i++) {
			hand *h = new hand(3);
			hands.push_back(h);
		}
		for (int i = 0; i < 2; i++) {
			foot *f = new foot(2);
			feet.push_back(f);
		}
		this->p_number = p_number;
		p_type = "alien";
		this->player_is_dead = false;
		starting_h_dead = false;
		my_turn = false;
		i_skip_turn = false;
	};
};

class Zombie : public Player{
public:
	Zombie(int p_number) {
		for (int i = 0; i < 1; i++) {
			hand *h = new hand(4);
			hands.push_back(h);
		}
		this->p_number = p_number;
		this->p_type = "zombie";
		this->player_is_dead = false;
		starting_h_dead = false;
		my_turn = false;
		i_skip_turn = false;
	};
};

class Doggo : public Player{
public:
	Doggo(int p_number) {
		for (int i = 0; i < 4; i++) {
			foot *f = new foot(4);
			feet.push_back(f);
		}
		this->p_number = p_number;
		p_type = "doggo";
		this->player_is_dead = false;
		starting_h_dead = false;
		my_turn = false;
		i_skip_turn = false;
	};
};

int num_teams;
int num_players;

void translate(string a, int *att_no, string *att_part, string b, int *rec_no, string *rec_part) {

	if (a[0] == 'H'){
		*att_part = "hand";
	} else if (a[0] == 'F'){
		*att_part = "foot";
	}

	if (b[0] == 'H'){
		*rec_part = "hand";
	} else if (b[0] == 'F'){
		*rec_part = "foot";
	}

	*att_no = (int) a[1] - 65;
	*rec_no = (int) b[1] - 65;

}

string findNextPlayer(int team, int *currentTeamIndex, vector<vector<Player*>> &v_of_teams, bool &zombieTurn, vector<int> &skippedPlayerNums) {
    
	bool found = false; string nextPlayer; int new_index;
    //next team
    while (!found) {
		//zombie turn
		if (zombieTurn) {
			zombieTurn = false;
			return to_string(team) + " " + to_string(currentTeamIndex[team]-1);
		}
        team = (team + 1) % num_teams;
        //iterate each player in the team
		int counter = 0;
        for (int i = currentTeamIndex[team]; counter < 2 ; (i + 1) % v_of_teams[team].size()){
			if (i == currentTeamIndex[team]) {
				counter++;
			}

			//if no anomalies
			if (v_of_teams[team][i]->playerAlive() && !v_of_teams[team][i]->getSkipTurn()){
				//setup nextPlayer
				//zombie case
				if (v_of_teams[team][i]->getPlayerType() == "zombie" && counter < 2) {
					zombieTurn = true;
				}
				nextPlayer = to_string(team) + " " + to_string(i);
				//ready next player currentTeamIndex
				new_index = i; 
				break;
            }
			//player is skipped
            else if (v_of_teams[team][i]->playerAlive() && v_of_teams[team][i]->getSkipTurn()){
				skippedPlayerNums.push_back(v_of_teams[team][i]->getPlayerNum());
                v_of_teams[team][i]->setSkipTurn(false);
				i = (i + 1) % v_of_teams[team].size();
			}
			else if (!v_of_teams[team][i] -> playerAlive()) {
				i = (i + 1) % v_of_teams[team].size();
			}	
        }
		if (counter < 2) {
			found = true;
			new_index = (new_index + 1) % v_of_teams[team].size();
		}
    }
	currentTeamIndex[team] = new_index;
    return nextPlayer;
}

bool verifyPlayerType(string player) {
	if (player != "human" && player != "alien" && player != "zombie" && player != "doggo") {
		return false;
	}
	if (!player.empty() && player.find_first_not_of("0123456789") == std::string::npos) {
		return false;
	}
	return true;
}

bool checkValidTeams(vector<vector<Player*>> &v_of_teams) {
	if (v_of_teams.size() < 2 || v_of_teams.size() > 6) return false;
	for (int i = 0; i < v_of_teams.size(); i++) {
		if (v_of_teams[i].empty()) {
			return false;
		}
	}
	return true;
}

void runServer(int serverPort) {
	int i;
	string numPlayersAsString;
	bool validNumOfPlayers = false;
	while (!validNumOfPlayers) {
		cout << "Enter number of players: ";
		cout << endl;
		cin >> numPlayersAsString;
		try {
			num_players = stoi(numPlayersAsString);
		}
		catch (invalid_argument &e) {
			cout << "Please enter numbers only!\n";
			continue;
		}
		if (num_players > 6 || num_players < 2) {
			cout << "Invalid input! The number of possible players are 2-6\n";
		}
		else {
			validNumOfPlayers = true;
		}
	}

	cout << endl;
	socketstream sockets[num_players-1];
	socketstream listening_socket;
	int numSockets = num_players-1;

	listening_socket.open(to_string(serverPort), numSockets);
	cout << "Waiting for all players..." << endl;
	int PlayerIndex = 0; //index of Server
	cout << "You are Player 1!" << endl;

	for (int i = 0; i < num_players-1; i++) {
		listening_socket.accept(sockets[i]);
		cout << "Player " << (i+2) << " connected!" << endl;
	}

	cout << "All Players Connected!" << endl;

	//sending the player's index
	for(int i = 0; i < num_players-1; i++) {
		sockets[i] << i+1 << endl;
	}

	vector<vector<Player*>> v_of_teams;
	vector<Player*> allPlayers;

/*-----------------------------SPECIFYING ALL PLAYER TYPES----------------------------------*/
	string player;
	for (i = 0; i < num_players; i++) {
		bool validPlayerType = false;
		if (i == 0) {
			while (!validPlayerType) {
				cout << "What is your player type (human, alien, zombie, doggo): ";
				cin >> player;
				validPlayerType = verifyPlayerType(player);
				if (!validPlayerType) {
					cout << "Please enter a valid player type!\n";
				}
			}
		}
		else {
			while (!validPlayerType) {
				cout << "Waiting for Player " << i+1 << " to input player type..." << endl;
				sockets[i-1] >> player;
				sockets[i-1].ignore();
				validPlayerType = verifyPlayerType(player);
				sockets[i-1] << validPlayerType << endl;
				if (!validPlayerType) {
					cout << "Please enter a valid player type!\n";
				}
			}
		}
		if (player == "human") {
			Human *human = new Human(i + 1);
			allPlayers.push_back(human);
		}
		else if (player == "alien") {
			Alien *alien = new Alien(i + 1);
			allPlayers.push_back(alien);
		}
		else if (player == "zombie") {
			Zombie *zombie = new Zombie(i + 1);
			allPlayers.push_back(zombie);
		}
		else {
			Doggo *doggo = new Doggo(i + 1);
			allPlayers.push_back(doggo);
		}
	}
/*-----------------------------SPECIFYING ALL TEAMS----------------------------------*/
	int team_no;
	while (true) {
		for (int i = 0; i < num_players; i++) {
			if (i == 0) {
				cout << "What is your team number: ";
				cin >> team_no;
				cin.ignore();
			}
			else {
				cout << "Waiting for Player " << i+1 << " to input team number..." << endl;
				sockets[i-1] >> team_no;
			}
			if (v_of_teams.size() < team_no) {
				for (int i = v_of_teams.size(); i < team_no; i++) {
					vector<Player*> T;
					v_of_teams.push_back(T);
				}
			}
			v_of_teams[team_no-1].push_back(allPlayers[i]);
		}
		bool areTeamsValid = checkValidTeams(v_of_teams);
		for (int i = 0; i < num_players-1; i++) {
				sockets[i] << areTeamsValid << endl;
		}
		if (areTeamsValid) {
			break;
		}
		else {
			cout << "Wrong team formation!" << endl;
			v_of_teams.clear();
		}
	}

//*----------------------------------------------------------------------------------*/
	num_teams = v_of_teams.size();

	bool team_life[num_teams];
	//setup team_life
	for (int i = 0; i < num_teams; i++) {
		team_life[i] = true;
	}

	int currentTeamIndex[num_teams];
	for (int i = 0; i < num_teams; i++) {
		currentTeamIndex[i] = 0;
	}

	for(int i = 0; i < num_teams; i++) {
		v_of_teams[i][0]->setMyTurn(true);
	}

	for (int i = 0; i < num_players-1; i++) {
		sockets[i] << num_teams << endl;
	}
	
	string action, a, b, att_part, rec_part, distPart, distLine;
	int target, att_no, rec_no, turn = 0;
	vector<int> distNums;
	bool zombieTurn2 = false;

	int counter = num_teams;
	int r = 0, nth = 0, team = -1;
	int ignoreOnce[num_players] = {0};
/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~START OF CHOPSTICKS GAME~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/ 
	while (counter > 1) {

		cout << "Round: " << r << endl; r++;
		counter = num_teams;
		distNums.clear();

/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~PRINT PHASE~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/ 
		for (int i = 0; i < num_teams; i++) {
			cout << "Team " << i + 1 << ": ";
			string forClient = "";
			for (int j = 0; j < v_of_teams[i].size(); j++) {
				forClient += v_of_teams[i][j]->printPlayerState();
				if (j + 1 != v_of_teams[i].size()) {
					forClient += " | ";
				}
			}
			cout << forClient << endl;
			for (int i = 0; i < num_players-1; i++) {
				sockets[i] << forClient << endl;
			}
			cout << endl;
		}
/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~TURN PHASE~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
		vector<int> skippedPlayerNums;
		string currentPlayer = findNextPlayer(team, currentTeamIndex, v_of_teams, zombieTurn2, skippedPlayerNums);
		stringstream ss(currentPlayer);
		ss >> team >> turn;
		//sending player who has the current turn
		for (int i = 0; i < num_players-1; i++) {
			sockets[i] << v_of_teams[team][turn]->getPlayerNum() << endl;
		}
		//sending number of skipped players;
		for (int i = 0; i < num_players-1; i++) {
			sockets[i] << skippedPlayerNums.size() << endl;
		}
		//sending skipped players one by one
		for (int i = 0; i < num_players-1; i++) {
			for (int j = 0; j < skippedPlayerNums.size(); j++) {
				sockets[i] << skippedPlayerNums[j] << endl;
			}
		}

		cout << "Player " << v_of_teams[team][turn]->getPlayerNum() << "'s turn" << endl;
		//print all
/*~~~~~~~~~~~~~~~~~~~~~~~~~COMMAND PHASE~~~~~~~~~~~~~~~~~~~~*/
		bool valid = false;
		int socketNumTurn;
		while (!valid) {
			string clientmove = "";
			if (PlayerIndex == v_of_teams[team][turn]->getPlayerNum()-1) {
				cout << "Enter your move, Player 1: ";
				getline(cin, clientmove);
				cout << endl;
			} else {
				socketNumTurn = v_of_teams[team][turn]->getPlayerNum() - 2;
		
				if (ignoreOnce[socketNumTurn] == 0) {
					sockets[socketNumTurn].ignore();
					ignoreOnce[socketNumTurn] = 1;
				}
				getline(sockets[socketNumTurn], clientmove);
			}
			cout << "This is the input received from the player: " << clientmove << endl;
			stringstream ss2(clientmove);
			ss2 >> action;
			if (action == "tap") {
				ss2 >> a;
				ss2 >> target;
				ss2 >> b;
				translate(a, &att_no, &att_part, b, &rec_no, &rec_part);
				valid = v_of_teams[team][turn]->isTapValid(target, num_players, allPlayers[target-1], att_no, rec_no, a, b, v_of_teams, team);
			} else if (action == "disthands" || action == "distfeet") {
				if (action.find("hand") != string::npos) {
					distPart = "hand";
				} else distPart = "feet";

				while (ss2) {
					string num; 
					ss2 >> num; 
					if (num != "") {
						distNums.push_back(stoi(num));
					}
				}
				valid = v_of_teams[team][turn]->isDistValid(distNums);;
			}
			else {
				cout << "Invalid input!" << endl;
			}
			if (!valid) {
				cout << "Invalid input!\n";
			}
			if (PlayerIndex != v_of_teams[team][turn]->getPlayerNum()-1) {
				sockets[socketNumTurn] << valid << endl;
			}
		}
/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ACTION PHASE~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/

		if (action == "tap") {
			//cout<<"VVVV " << v_of_teams[turn][i]->hands[0]->fingers<<endl;
			v_of_teams[team][turn]->tap(allPlayers[target - 1], att_no, rec_no, att_part, rec_part);
		}
		else {
			v_of_teams[team][turn]->dist(distNums, distPart);
		}

/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~CHECK PHASE~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
		//initialize team life
		for (int j = 0; j < num_teams; j++) {
			team_life[j] = false;
		}

		for (int i = 0; i < num_teams; i++) {
			for (int j = 0; j < v_of_teams[i].size(); j++) {
				if (v_of_teams[i][j]->playerAlive()) team_life[i] = true;
			}
		}

		for (int i = 0; i < num_teams; i++) {
			if (!team_life[i]) counter--;
		}

		for (int i = 0; i < num_players-1; i++) {
			sockets[i] << counter << endl;
		}
	}
		cout << "The counter is: " << counter << endl;
	for (int i = 0; i < num_teams; i++) {
		cout << "Team " << i + 1 << ": ";
		string forClient = "";
		for (int j = 0; j < v_of_teams[i].size(); j++) {
			forClient += v_of_teams[i][j]->printPlayerState();
			if (j + 1 != v_of_teams[i].size()) {
				forClient += " | ";
			}
		}
		cout << forClient << endl;
		for (int i = 0; i < num_players-1; i++) {
			sockets[i] << forClient << endl;
		}
		cout << endl;
	}
    bool isPlayerWinner = false;

	for (int i = 0; i < num_teams; i++) {
		if (team_life[i]) {
            for (int j = 0; j < num_players-1; j++) {
				sockets[j] << i << endl; 
			}

            for (int j = 0; j < num_players-1; j++) {
                if (v_of_teams[0][0]->getPlayerNum() == v_of_teams[i][j]->getPlayerNum()) {
                    cout << "Congratulations! ";
                }
                for (int k = 0; k < v_of_teams[i].size(); k++) {
                    if (v_of_teams[i][k]->getPlayerNum() == j+2)
                }
                sockets[j] << isPlayerWinner << endl;
			}
			
			cout << "Team " << i+1 << " wins!";
		}
	}
}

void runClient(string ipAddress, int serverPort) {
	socketstream server;
	server.open(ipAddress, to_string(serverPort));
	cout << "Connected to server!\n";
	int PlayerIndex;
	string playertype;
	int team_no;
	int firstplayer;
	int num_teams;
	string move;
	int target, att_no, rec_no, turn = 0;
	vector<int> distNums;

	server >> PlayerIndex;
	server.ignore();

	cout << "You are Player " << PlayerIndex+1 << "!" << endl;
	bool validPlayerType = false;
	while (!validPlayerType) {
		cout << "What is your player type (human, zombie, alien, doggo): ";
		cin >> playertype;
		server << playertype << endl;
		server >> validPlayerType;
		server.ignore();
		if (!validPlayerType) {
			cout << "Please enter a valid player type!\n";
		}
	}
	cout << "\n";
	bool validTeamNum = false;
	while (!validTeamNum) {
		cout << "What is your team number: ";
		cin >> team_no;
		cin.ignore();
		server << team_no << endl;
		server >> validTeamNum;
		server.ignore();
		if (!validTeamNum) {
			cout << "Please enter a valid team number!\n";
		}
	}
	cout << "\n";

	cout << "Let's go!\n";

	server >> num_teams;
	server.ignore();
	
	cout << endl;
	
	int counter = num_teams;

	while (counter > 1) {

/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~PRINT PHASE~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/ 
		for (int i = 0; i < num_teams; i++) {
			cout << "Team " << i + 1 << ": ";
			cout << "(";
			string forClient = ")";
			getline(server, forClient);
			cout << forClient << ")\n";
		}
/*~~~~~~~~~~~~~~~~~~~~~~~~~TURN PHASE~~~~~~~~~~~~~~~~~~~~*/
		int whoseTurnIsIt;
		server >> whoseTurnIsIt;
		server.ignore();
		int numOfSkippedPlayers;
		server >> numOfSkippedPlayers;
		server.ignore();
		int playerNumOfSkippedPlayer;
		for (int i = 0; i < numOfSkippedPlayers; i++) {
			server >> playerNumOfSkippedPlayer;
			server.ignore();
			cout << "Player " << playerNumOfSkippedPlayer << " is skipped!\n";
		}
		cout << "Player " << whoseTurnIsIt << "'s turn" << "\n";
/*~~~~~~~~~~~~~~~~~~~~~~~~~COMMAND PHASE~~~~~~~~~~~~~~~~~~~~*/
		bool valid = false;
		if (PlayerIndex == whoseTurnIsIt-1) {
			while(!valid) {
				move = "";
				cout << "Enter your move: ";
				getline(cin, move);
				server << move << endl;
				server >> valid;
				server.ignore();
				if (!valid) {
					cout << "Your input is invalid. Please enter a proper move: ";
					cout << endl;
				}
			}
		} else {
			cout << "Waiting for Player " << whoseTurnIsIt << "\n";
		}
/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ACTION PHASE~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
		server >> counter;
		server.ignore();
/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~CHECK PHASE~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
	}
	for (int i = 0; i < num_teams; i++) {
			cout << "Team " << i + 1 << ": ";
			cout << "(";
			string forClient = ")";
			getline(server, forClient);
			cout << forClient << ")\n";
		}
	int winningTeam;
    bool amIWinner;
	server >> winningTeam;
    server >> amIWinner;
	server.ignore();
    if (amIWinner) {
        cout << "Congratulations! ";
    }
    else {
        cout << "You lose! ";
    }
	cout << "Team " << winningTeam + 1 << " wins!";
}

void checkPort(string portAsString) {
	int portAsInt;
	try {
			portAsInt = stoi(portAsString);
	}
	catch (std::invalid_argument& e){
			cout << "The server port must be an integer from 1024-65535\n";
	}

    if (portAsInt >= 1024 && portAsInt <= 65535 && to_string(portAsInt) == portAsString) {
				cout << "Valid port!\n";
	}
    else {
            throw std::runtime_error("The server port must be an integer from 1024-65535\n");
    }
}
int main(int argc, char *argv[]) {
    if (argc == 2) {
		checkPort(argv[1]);
		cout << "You are the Server and Player 1!\n";
		runServer(stoi(argv[1]));
    }
    else if (argc == 3) {
        checkPort(argv[2]);
		runClient(argv[1], stoi(argv[2]));
    }
}